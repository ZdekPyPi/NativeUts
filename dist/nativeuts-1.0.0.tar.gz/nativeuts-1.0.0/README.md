# NativeUts
#
### Installation

```sh
pip install nativeUts
```

## GitHub
https://github.com/ZdekPyPi/NativeUts


## Usage
#

# LIST — Exemplo de Uso

## `list.group`

```python
from nativeUts.list import *

a = [1, 2, 3, 4, 5, 6, 7]
print(a.group(3))
#[[1, 2, 3], [4, 5, 6], [7]]
```



# NUMBER  — Exemplo de Uso

## `float.numberToBr`

```python
from nativeUts.number import *

valor = 12345.678
print(valor.numberToBr())
#12.345,68
```

# STRING — Exemplo de Uso

## `str.only_numbers`

```python
from nativeUts.string import *

print("abc123d4".only_numbers())
#1234
```

## `str.only_numbers`
```python

```

## `str.usToNumber`
```python
from nativeUts.string import *

print("12,345.67".usToNumber())
#12345.67
```

## `str.brToNumber`
```python
from nativeUts.string import *

print("R$ 12.345,67".brToNumber())
#12345.67
```

## `str.joinPath`
```python
from nativeUts.string import *

print("home/user".joinPath("docs", "file.txt"))
#home/user/docs/file.txt
```

## `str.joinUrl`
```python
from nativeUts.string import *

print("https://site.com".joinUrl("api", "v1"))
#https://site.com/api/v1
```

## `str.fileName`
```python
from nativeUts.string import *

print("/home/user/file.txt".fileName())
#file.txt
```
## `str.isEmail`
```python
from nativeUts.string import *

print("user@mail.com".isEmail())
#True
```
## `str.isLike`
```python
from nativeUts.string import *

print("AB123".isLike(r"[A-Z]{2}[0-9]{3}"))
#True
```
## `str.regx`
```python
from nativeUts.string import *

print("abc123xyz456".regx(r"\d+"))
#['123', '456']
```
